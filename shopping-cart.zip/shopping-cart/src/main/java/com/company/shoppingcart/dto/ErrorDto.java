package com.company.shoppingcart.dto;
import org.springframework.http.HttpStatus;

public class ErrorDto {
    private HttpStatus httpStatus;
    private String message;

    public ErrorDto(Exception e) {
        this(e.getMessage());
    }

    public ErrorDto(String message) {
        this(HttpStatus.BAD_REQUEST, message);
    }

    public ErrorDto(HttpStatus httpStatus, String message) {
        this.httpStatus = httpStatus;
        this.message = message;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    public String getMessage() {
        return message;
    }
}
