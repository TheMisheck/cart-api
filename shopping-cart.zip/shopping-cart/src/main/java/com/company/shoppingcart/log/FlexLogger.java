package com.company.shoppingcart.log;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class FlexLogger {


    public static final String TAG = FlexLogger.class.getSimpleName();
    private static Logger mLogger;
    private static FlexLogger mInstance;

    private FlexLogger() {
    }

    public static FlexLogger getInstance() {
        if (mInstance == null) {
            mInstance = new FlexLogger();
            mLogger = Logger.getLogger(TAG);
            mLogger.setUseParentHandlers(false); //To remove the console handler, use
            try {
                SimpleDateFormat format = new SimpleDateFormat("M-d_HH");
                File file = createDirectory("logs");
                FileHandler mFileHandler;
                if (file != null){
                    mFileHandler = new FileHandler("logs/logs_" + format.format(new Date()) + ".log");
                } else {
                    mFileHandler = new FileHandler("logs_" + format.format(new Date()) + ".log");
                }
                SimpleFormatter formatter = new SimpleFormatter();
                mFileHandler.setFormatter(formatter);
                mLogger.addHandler(mFileHandler);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return mInstance;
    }

    public static File createDirectory(String directoryPath) {
        File dir = new File(directoryPath);
        if (dir.exists()) {
            return dir;
        }
        if (dir.mkdirs()) {
            return dir;
        }
        BeeLog.log("Failed to create directory '" + dir.getAbsolutePath() + "' for an unknown reason.");
        return null;
    }

    public void log(String tag, Object msg) {
        mLogger.info(tag + " : " + String.valueOf(msg) +
                "\n*****************************************************************************\n");
    }
}

