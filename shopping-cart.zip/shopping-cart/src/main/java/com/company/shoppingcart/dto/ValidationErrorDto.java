package com.company.shoppingcart.dto;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ValidationErrorDto {
    private List<FieldErrorDto> fieldErrors = new ArrayList<>();
    private String message;
    private MessageSource messageSource;

    public ValidationErrorDto(MethodArgumentNotValidException ex, MessageSource messageSource) {
        BindingResult result = ex.getBindingResult();
        List<FieldError> fieldErrors = result.getFieldErrors();
        this.messageSource = messageSource;
        for (FieldError fieldError: fieldErrors) {
            String localizedErrorMessage = resolveLocalizedErrorMessage(fieldError);
            this.addFieldError(fieldError.getField(), localizedErrorMessage);
        }
        this.message = ex.getMessage();
    }


    private String resolveLocalizedErrorMessage(FieldError fieldError) {
        Locale currentLocale =  LocaleContextHolder.getLocale();
        String localizedErrorMessage = messageSource.getMessage(fieldError, currentLocale);

        //If the message was not found, return the most accurate field error code instead.
        //You can remove this check if you prefer to get the default error message.
        if (localizedErrorMessage.equals(fieldError.getDefaultMessage())) {
            String[] fieldErrorCodes = fieldError.getCodes();
            localizedErrorMessage = fieldErrorCodes != null ? fieldErrorCodes[0] : null;
        }

        return localizedErrorMessage;
    }

    private void addFieldError(String path, String message) {
        FieldErrorDto error = new FieldErrorDto(path, message);
        fieldErrors.add(error);
    }

    public List<FieldErrorDto> getFieldErrors() {
        return fieldErrors;
    }

    public String getMessage() {
        return message;
    }
}
