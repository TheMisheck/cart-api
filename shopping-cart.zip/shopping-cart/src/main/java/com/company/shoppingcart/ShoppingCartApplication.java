package com.company.shoppingcart;

import com.company.shoppingcart.model.User;
import com.company.shoppingcart.repository.UserRepository;
import com.company.shoppingcart.service.UserService;
import org.knowm.sundial.SundialJobScheduler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingCartApplication  { //implements CommandLineRunner
    private final
    UserRepository userRepository;

    private final
    UserService userService;


    @Autowired
    public ShoppingCartApplication(UserService userService,
                       UserRepository userRepository) {
        this.userService = userService;
        this.userRepository = userRepository;
    }

	public static void main(String[] args) {
		SpringApplication.run(ShoppingCartApplication.class, args);
	}
//    @Override
//    public void run(String... params) {
//        userRepository.deleteAll();
//        User admin = new User();
//        admin.setUsername("admin");
//        admin.setPassword("admin");
//        admin.setEmail("info@flexcom.co.ke");
//        admin.setFirstName("Admin First Name");
//        admin.setMiddleName("Admin Middle Name");
//        admin.setLastName("Admin Last Name");
//        userService.addUser(admin);
//        userService.addUser(admin);
//    }


}

